# BOSS Episode 01 · React + Tailwind Design Master · Candidate 0.2

This corrects the previous SVG-driven artifact. The layout, typography, diagrams, stages, and rail components are built from **React JSX and Tailwind CSS utility classes**, not an SVG slide.

## Run

```bash
npm install
npm run dev
```

Open the local address from Vite. Use `npm run build` for production static assets.

## Source structure
- `src/main.jsx` — React component tree (`Slide`, `Rail`, `SequenceVisual`, `PrecedenceVisual`, `GroupingVisual`)
- `src/styles.css` — Tailwind import and print/container styles
- `vite.config.js` — React and Tailwind Vite plugins
- `package.json` — reproducible project dependencies

**Status:** code-only candidate. Dependencies were not installed or compiled in this sandbox, and this is NOT a rendered or QA-approved replacement of the PDF. Review in Vite browser before treating as the master. The existing Episode 01 PDF remains reference material; canonical script verification remains pending.
